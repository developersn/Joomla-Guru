<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('sncore.include');
jimport('joomla.application.menu');
jimport('joomla.html.parameter');

class plgGurupaymentSn_guru extends JPlugin
{
	var $_db = null;
    
	function __construct(&$subject, $config)
	{
        SNGlobal::loadLanguage('plg_gurupayment_sn_guru',JPATH_ADMINISTRATOR);

		$this->_db = JFactory :: getDBO();
		parent :: __construct($subject, $config);
	}
	
	/* Request */
	function onSendPayment(&$post)
	{
		if($post['processor'] != 'sn_guru')
		{
		    return false;
		}

        $app = JFactory::getApplication();
        $orderId = $post['order_id'];

        $pin = $this->params->get('sn_pin','');
        $currency = $this->params->get('sn_currency','');
        $sendPayerInfo = $this->params->get('sn_send_payer_info','');

        $backUrl = JUri::root().'index.php?option=com_guru&controller=guruBuy&processor='.$post['processor'].'&task='.$post['task'].'&sid='.$post['sid'].'&order_id='.$post['order_id'].'&customer_id='.intval($post['customer_id']).'&pay=wait';
        $cancelUrl = JRoute::_('index.php?option=com_guru&view=gurubuy',false);

        $amount = 0;
        foreach (!empty($post['products']) ? $post['products'] : array() as $key => $value)
        {
            $amount += isset($value['value']) ? $value['value'] : 0;
        }

        $amount = SNApi::modifyPrice($amount,$currency);

        $data = array(
            'pin'=> $pin,
            'price'=> $amount,
            'callback'=> $backUrl,
            'order_id'=> $orderId,
            'mobile'=> '',
        );

        list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'guru');

        if($status == true)
        {
            $data['bank_callback_details'] = $resultData['bank_callback_details'];
            $data['au'] = $resultData['au'];

            SNApi::clearData();
            SNApi::setData($data);

            $html = SNGlobal::postData($resultData['form_details']['action'],$resultData['form_details']['fields'],100);
            $html .= '<h5 class="gr-connect-to-bank">'.JText::_('SN_CONNECTING_TO_PORTAL').'</h5>';
            return $html;
        }

        $msg = $msg;
        $app->redirect($cancelUrl, '<h5>'.$msg.'</h5>', $msgType='error');
	}
	
	/* Verify */
	function onReceivePayment(&$post)
	{
        $app = JFactory::getApplication();
		$return = 0;
        $orderId = SNGlobal::getVar('order_id',0);
        $au = SNGlobal::getVar('au',0);

        if($post['processor'] != 'sn_guru')
        {
            return false;
        }

        $sessionData = SNApi::getData();

		if(!empty($orderId) && !empty($au) && !empty($sessionData) && $sessionData['order_id'] == $orderId)
		{
            $bankData = array();
            foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
            {
                $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
            }

            $data = array (
                'pin' => $sessionData['pin'],
                'price' => $sessionData['price'],
                'order_id' => $sessionData['order_id'],
                'au' => $au,
                'bank_return' => $bankData,
            );

            list($status,$msg,$resultData) = SNApi::verify($data,'guru');

			if($status != true)
			{
                $cancelUrl = JRoute::_('index.php?option=com_guru&view=gurubuy',false);

                $msg = JText::_('SN_UNPAID_TRANSACTION');
                $app->redirect($cancelUrl, '<h5>'.$msg.'</h5>', $msgType='error');
			}
			else
			{
				$return = array(
					'sid' => $post['sid'],
					'order_id' => $post['order_id'],
					'pay' => 'success',
				);
			}
		}
		
		return $return;
	}
	
	function onCheckParams($params)
    {

	}
}
?>